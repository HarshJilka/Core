<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

li {
  float: left;
}

li a {
  display: block;
  padding: 8px;
  background-color: #blue;
}
ul{
  background-color: skyblue;
  margin-bottom: 10px;
  margin: auto;
  margin-bottom: 10px;
  padding-left: 620px;
}
</style>
</head>
<body>

<ul>

<li><a href="index.php?c=admin&a=grid">Admin</a></li>
<li><a href="index.php?c=category&a=grid">Category</a></li>
<li><a href="index.php?c=customer&a=grid">Customer</a></li>
<li><a href="index.php?c=product&a=grid">Product</a></li>
</ul>

</body>
</html>





   

    